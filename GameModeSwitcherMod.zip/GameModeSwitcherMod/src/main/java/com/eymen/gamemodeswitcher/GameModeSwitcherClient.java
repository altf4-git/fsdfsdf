package com.eymen.gamemodeswitcher;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;
import org.lwjgl.glfw.GLFW;

public class GameModeSwitcherClient implements ClientModInitializer {
    private static KeyBinding creativeKeyBinding;
    private static KeyBinding survivalKeyBinding;

    @Override
    public void onInitializeClient() {
        creativeKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.gamemodeswitcher.creative",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "category.gamemodeswitcher.keys"
        ));

        survivalKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.gamemodeswitcher.survival",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_S,
                "category.gamemodeswitcher.keys"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.interactionManager == null) return;

            long windowHandle = client.getWindow().getHandle();
            boolean isAltPressed = InputUtil.isKeyPressed(windowHandle, GLFW.GLFW_KEY_LEFT_ALT) || 
                                   InputUtil.isKeyPressed(windowHandle, GLFW.GLFW_KEY_RIGHT_ALT);

            if (isAltPressed && creativeKeyBinding.wasPressed()) {
                client.interactionManager.setGameMode(GameMode.CREATIVE);
                client.player.sendMessage(Text.literal("§a[Mod] §eYaratıcı (Creative) §fmoda geçildi!"), true);
            }

            if (client.currentScreen == null && survivalKeyBinding.wasPressed()) {
                client.interactionManager.setGameMode(GameMode.SURVIVAL);
                client.player.sendMessage(Text.literal("§c[Mod] §eHayatta Kalma (Survival) §fmoduna geçildi!"), true);
            }
        });
    }
}
